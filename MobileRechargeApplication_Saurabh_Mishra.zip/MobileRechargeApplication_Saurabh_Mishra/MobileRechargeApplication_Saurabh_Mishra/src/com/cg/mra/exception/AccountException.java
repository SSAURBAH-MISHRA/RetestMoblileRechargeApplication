package com.cg.mra.exception;

@SuppressWarnings("serial")
public class AccountException extends Exception {
	public AccountException(String message) {
		
		super(message);
	}

}
