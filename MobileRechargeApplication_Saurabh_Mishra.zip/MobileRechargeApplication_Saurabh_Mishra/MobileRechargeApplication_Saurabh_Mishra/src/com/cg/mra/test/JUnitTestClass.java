package com.cg.mra.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class JUnitTestClass {
	AccountService accountService; // Reference of AccountService class.

	@Before
	public void setUp() throws Exception {
		accountService = new AccountServiceImpl();
	}

	public JUnitTestClass() {
	}

	@Test(expected = AccountException.class)
	public void ValidateMobileNumberTest1() throws AccountException { // to check if mobileNo is null.
		accountService.validateMobileNumber(null);

	}

	@Test
	public void ValidateMobileNumberTest2() throws AccountException { // to check if mobileNo is less than 10 digits.
		boolean result = accountService.validateMobileNumber("62");
		assertEquals(false, result);

	}

	@Test
	public void ValidateMobileNumberTest3() throws AccountException { // to check if mobileNo does not have number digits.
		boolean result = accountService.validateMobileNumber("jhsgdjg");
		assertEquals(false, result);

	}

	@Test
	public void ValidateMobileNumberTest4() throws AccountException { // to check if mobileNo is of correct format.
		boolean result = accountService.validateMobileNumber("6985231470");
		assertEquals(true, result);

	}

	@Test
	public void ValidateMobileNumberTest5() throws AccountException {
		boolean result = accountService.validateMobileNumber("78965412023"); // to check if mobileNo is greater than 10 digits.
		assertEquals(false, result);

	}

	@Test
	public void ValidateRechargeAmountTest6() throws AccountException {
		boolean result = accountService.validateRechargeAmount(-25); // to check if the Recharge amount is negative .
		assertEquals(false, result);

	}

	@Test
	public void ValidateRechargeAmountTest7() throws AccountException {
		boolean result = accountService.validateRechargeAmount(100); // to check if recharge amount is in correct format.
		assertEquals(true, result);

	}

	@Test(expected = AccountException.class)
	public void ValidateRechargeAmountTest8() throws AccountException {
		accountService.validateRechargeAmount(0);

	}
}
