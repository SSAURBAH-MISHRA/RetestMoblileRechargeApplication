package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;

public interface AccountService {
	// Method Definition to get the Account Details.
	public Account getAccountDetails(String mobileNo);

	// Method Definition that recharges the Customer's Account.
	public double rechargeAccount(String mobileNo, double rechargeAmount);

	// Method Definition to validate the Mobile number.
	boolean validateMobileNumber(String mobileNo) throws AccountException;

	// Method Definition to validate the recharge Amount.
	boolean validateRechargeAmount(double rechargeAmount) throws AccountException;

}
