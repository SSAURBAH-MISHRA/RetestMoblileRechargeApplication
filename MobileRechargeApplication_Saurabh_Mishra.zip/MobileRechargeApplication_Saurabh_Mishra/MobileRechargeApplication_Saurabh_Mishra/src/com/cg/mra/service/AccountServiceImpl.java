package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	AccountDao accountDao; // Reference of AccountDao Class.

	public AccountServiceImpl() {
		accountDao = new AccountDaoImpl();
	}

	@Override
	// Method Declaration to get the Account Details.
	public Account getAccountDetails(String mobileNo) {
		return accountDao.getAccountDetails(mobileNo);
	}

	@Override
	// Method Declaration that recharges the Customer's Account.
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
	}

	@Override
	// Method Declaration to validate the Mobile number
	public boolean validateMobileNumber(String mobileNo) throws AccountException {
		if (mobileNo == null)
			throw new AccountException("Number connot be zero");
		Pattern pat = Pattern.compile("[6-9]{1}[0-9]{2,9}");		//if the first digit of mobile number is between 6-9,
		Matcher mat = pat.matcher(mobileNo);						//and rest of the digit is in between 0-9,
		return mat.matches();										//then it will return true.

	}

	@Override
	// Method Declaration to validate the recharge Amount.
	public boolean validateRechargeAmount(double rechargeAmount) throws AccountException {
		if (rechargeAmount > 0) {
			return true;
		} else if (rechargeAmount == 0) {
			throw new AccountException("Recharge Amount cannot be zero");
		}
		return false;

	}
}