package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	static Scanner scanner;
	static AccountService accountService; // Reference of AccountService Class.

	public static void main(String[] args) throws AccountException {
		accountService = new AccountServiceImpl();
		scanner = new Scanner(System.in);
		int choice = 0;
		while (true) {

			System.out.println("******************Welcome to Mobile Recharge Application****************");
			System.out.println("\n1. Account Balance Enquiry ");
			System.out.println("2. Recharge Account ");
			System.out.println("3. Exit ");

			System.out.println("Enter your choice: ");
			choice = scanner.nextInt();
			switch (choice) {

			case 1:
				accountBalanceEnquiry();
				break;

			case 2:
				rechargeAccount();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("Please! Enter a valid choice.");

			}
		}
	}

	private static void rechargeAccount() throws AccountException {
		System.out.println("Enter MobileNo : ");
		String mobileNumber = scanner.next();
		System.out.println("Enter Recharge Amount : ");
		double amount = scanner.nextDouble();
		if (accountService.validateMobileNumber(mobileNumber)) // first if for validating mobile number.
		{
			if (amount == 0) { // Second if for ensuring recharge amount cannot be zero
				System.out.println("Recharge amount cannot be zero");
			} // end of Second if.
			else if (accountService.validateRechargeAmount(amount)) // else if for validating recharge amount
			{
				double newbalance = accountService.rechargeAccount(mobileNumber, amount);
				if (newbalance == 0) { // Third if, method returns 0 if no mobile number is existing
					System.out.println("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exists ");
				} // end of Third if.
				else {
					Account account1 = accountService.getAccountDetails(mobileNumber);
					System.out.println("Your Account Recharged Successfully");
					System.out.println(
							"Hello " + account1.getCustomerName() + ", Available Balance is " + newbalance + ".");
				}
			} // end of else if
			else
				System.out.println("Enter valid Recharge Amount");

		} // end of First if.
		else
			System.out.println("Enter 10 digit Mobile Number");
	}

	private static void accountBalanceEnquiry() throws AccountException {
		System.out.println("Enter Mobile No : ");
		String mobileNo = scanner.next();
		if (accountService.validateMobileNumber(mobileNo)) {
			Account account = accountService.getAccountDetails(mobileNo);
			if (account == null) {
				System.out.println("ERROR: Given Account Id Does Not Exist ");
			} else
				System.out.println("Your Current Balance is Rs. " + account.getAccountBalance());
		}

		else
			System.out.println("Enter 10 digit Mobile Number");
	}
}