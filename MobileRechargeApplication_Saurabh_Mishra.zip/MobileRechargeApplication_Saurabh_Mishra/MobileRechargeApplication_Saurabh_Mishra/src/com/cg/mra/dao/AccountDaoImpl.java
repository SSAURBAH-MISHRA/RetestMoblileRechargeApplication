package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	Map<String, Account> accountEntry;					//HashMap accountEntry to store MobileNumber as Key and
														//Account object as Value.

	public AccountDaoImpl() {
		accountEntry = new HashMap<>();
		accountEntry.put("9010210133", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453)); 	// In the question paper, duplicate keys are given,
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 200)); 	// that's why I have made some modifications
		accountEntry.put("9010210131", new Account("Prepaid", "Anju", 200)); 	// in the Key values.
		accountEntry.put("9010210123", new Account("Prepaid", "Tushar", 632));
	}

	@Override
	// Method Declaration to get the Account Details.
	public Account getAccountDetails(String mobileNo) {
		if (accountEntry.containsKey(mobileNo))					//if HashMap contains mobileNo,
			return accountEntry.get(mobileNo);					//then it will return Account object of HashMap.	
		return null;
	}

	@Override
	// Method Declaration that recharges the Customer's Account.
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		double balance = 0;
		if (accountEntry.containsKey(mobileNo)) {					//if HashMap contains mobileNo,
			Account acc = accountEntry.get(mobileNo);				//then it will the updated balance.
			balance = rechargeAmount + acc.getAccountBalance();
			acc.setAccountBalance(balance);
		}
		return balance;
	}

}